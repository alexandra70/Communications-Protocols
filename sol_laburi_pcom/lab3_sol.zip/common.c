#include "common.h"

uint16_t inet_csum(uint8_t *buf, size_t len) {
	uint16_t ret = 0;
	uint16_t *words = (void *) buf;
	size_t words_len = len / 2;

	for (size_t idx = 0; idx < words_len; idx++) {
		uint32_t tmp = ret + ~words[idx];
		ret = tmp + (tmp >> 16);
	}

	if (len & 1) {
		uint32_t tmp = ret + ~(buf[len - 1] << 8);
		ret = tmp + (tmp >> 16);
	}

	return ret;
}

uint8_t hamming_4to7(uint8_t c) {
	bool d1 = (c >> 3) & 1;
	bool d2 = (c >> 2) & 1;
	bool d3 = (c >> 1) & 1;
	bool d4 = (c >> 0) & 1;

	bool p1 = d1 ^ d2 ^ d4;
	bool p2 = d1 ^ d3 ^ d4;
	bool p3 = d2 ^ d3 ^ d4;

	return (p1 << 6) | (p2 << 5) | (d1 << 4) | (p3 << 3)
		 | (d2 << 2) | (d3 << 1) | (d4 << 0);
}

uint8_t hamming_7to4(uint8_t c) {
	bool r1 = (c >> 6) & 1;
	bool r2 = (c >> 5) & 1;
	bool r3 = (c >> 4) & 1;
	bool r4 = (c >> 3) & 1;
	bool r5 = (c >> 2) & 1;
	bool r6 = (c >> 1) & 1;
	bool r7 = (c >> 0) & 1;

	bool z1 = r1 ^ r3 ^ r5 ^ r7;
	bool z2 = r2 ^ r3 ^ r6 ^ r7;
	bool z3 = r4 ^ r5 ^ r6 ^ r7;

	uint8_t z = (z3 << 2) | (z2 << 1) | (z1 << 0);

	switch (z) {
		case 3:
			r3 ^= 1;
			break;

		case 5:
			r5 ^= 1;
			break;

		case 6:
			r6 ^= 1;
			break;

		case 7:
			r7 ^= 1;
			break;

		default:
			break;
	}

	return (r3 << 3) | (r5 << 2) | (r6 << 1) | (r7 << 0);
}
