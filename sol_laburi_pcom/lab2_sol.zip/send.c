#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "link_emulator/lib.h"
#include "common.h"

#define HOST 	"127.0.0.1"
#define PORT 	10000

int main(int argc, char *argv[])
{
	msg t;
	my_pkt p;
	int fd, count, filesize;
	struct stat f_status;
	char buffer[MAX_LEN];
	
	init(HOST, PORT);
	printf("[SENDER] Server rocks.\n");
	printf("[SENDER] File to send: %s\n", argv[1]);

	fd = open(argv[1], O_RDONLY);
	fstat(fd, &f_status);
	
	filesize = (int) f_status.st_size;
	printf("[SENDER] File size: %d\n", filesize);

	/* Len in message 
		= size(msg payload)
		= amount of data in the my_pkt structure
		= size(type) + data in (pkt payload)
		= sizeof(int) + number of used bytes in (pkt payload)
	*/

	/* Gonna send filename - TYPE 1 message */
	memset(t.payload, 0, sizeof(t.payload));
	memset(p.payload, 0, sizeof(p.payload));
	
	p.type = TYPE1;	
	memcpy(p.payload, argv[1], strlen(argv[1]));
	t.len = sizeof(int) + strlen(argv[1]);
	memcpy(t.payload, &p, t.len); 
	send_message(&t);
	printf("[SENDER] Filename sent.\n");

	/* Wait for filename ACK */	
	if (recv_message(&t) < 0) {
		perror("[SENDER] Receive error");
		return -1;
	}
	
	p = *((my_pkt *) t.payload);
	if (p.type != TYPE4) {
		perror("[SENDER] Receive error");
		return -1;
	}
	printf("[SENDER] Got reply with payload: %s\n", p.payload);
	
	/* Gonna send filesize - TYPE 2 message */
	memset(t.payload, 0, sizeof(t.payload));
	memset(p.payload, 0, sizeof(p.payload));
	
	p.type = TYPE2;
	memcpy(p.payload, &filesize, sizeof(int));
	t.len = sizeof(int) * 2;
	memcpy(t.payload, &p, t.len);
	send_message(&t);
	printf("[SENDER] Filesize sent.\n");
	
	/* Wait for filesize ACK */	
	if (recv_message(&t) < 0) {
		perror("[SENDER] Receive error");
		return -1;
	}
	
	p = *((my_pkt *) t.payload);
	if (p.type != TYPE4) {
		perror("[SENDER] Receive error");
		return -1;
	}
	printf("[SENDER] Got reply with payload: %s\n", p.payload);

	/* Send file contents - TYPE 3 messages */
	printf("[SERVER] File transfer begins.\n");
	while((count = read(fd, buffer, MAX_LEN - sizeof(int))) > 0) {
		memset(t.payload, 0, sizeof(t.payload));
		memset(p.payload, 0, sizeof(p.payload));
		
		p.type = TYPE3;
		memcpy(p.payload, buffer, count);
		t.len = sizeof(int) + count;
		memcpy(t.payload, &p, t.len);
		send_message(&t);

		if (recv_message(&t) < 0) {
			perror("[SENDER] Receive error");
			return -1;
		}
		
		p = *((my_pkt *) t.payload);
		if (p.type != TYPE4) {
			perror("[SENDER] Receive error");
			return -1;
		}
	}
	
	printf("[SERVER] File transfer has ended.\n");	
	close(fd);
	
	return 0;
}
